package com.yandex.app.model;

public enum Status {
    NEW,
    IN_PROGRESS,
    DONE
}
